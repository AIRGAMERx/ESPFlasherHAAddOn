from flask import Flask, request, jsonify, send_from_directory
import os
import subprocess
from flask_cors import CORS
import json
import traceback  # Wichtig für bessere Fehlerlogs

app = Flask(__name__, static_folder="/app/www", static_url_path="/")
CORS(app)

YAML_DIR = "/app/data"
OUTPUT_DIR = "/app/www/firmware"

# Sicherstellen, dass Verzeichnisse existieren
os.makedirs(YAML_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)

@app.route("/compile", methods=["POST"])
def compile_yaml():
    data = request.get_json()
    name = data.get("name", "device").replace(" ", "_").lower()
    config = data.get("configuration", "")

    if not config:
        return jsonify({"status": "error", "message": "No YAML config provided"}), 400

    yaml_path = os.path.join(YAML_DIR, f"{name}.yaml")
    with open(yaml_path, "w") as f:
        f.write(config)

    print(f"📥 YAML gespeichert: {yaml_path}")
    print("📄 YAML-Inhalt:")
    print(config)

    try:
        print("⚙️ Starte esphome compile...")
        result = subprocess.run(
            ["esphome", "compile", yaml_path],
            capture_output=True, text=True, timeout=300
        )

        print("📤 esphome stdout:")
        print(result.stdout)
        print("📛 esphome stderr:")
        print(result.stderr)

        if result.returncode != 0:
            print("❌ Kompilierung fehlgeschlagen!")
            return jsonify({
                "status": "error",
                "command": result.args,
                "stdout": result.stdout,
                "stderr": result.stderr
            }), 500

        bin_path = f"/app/{name}/.pioenvs/{name}/firmware.bin"
        output_bin = os.path.join(OUTPUT_DIR, f"{name}.bin")

        if not os.path.isfile(bin_path):
            print(f"❌ Binärdatei nicht gefunden: {bin_path}")
            return jsonify({
                "status": "error",
                "message": "Compiled firmware not found.",
                "bin_path": bin_path
            }), 500

        os.rename(bin_path, output_bin)
        print(f"✅ Firmware gespeichert: {output_bin}")

        manifest_data = {
            "name": f"{name} Firmware",
            "version": "1.0.0",
            "builds": [
                {
                    "chipFamily": "ESP32",
                    "parts": [
                        {
                            "path": f"firmware/{name}.bin",
                            "offset": 0
                        }
                    ]
                }
            ]
        }

        manifest_path = os.path.join(OUTPUT_DIR, f"{name}.manifest.json")
        with open(manifest_path, "w") as f:
            json.dump(manifest_data, f)

        print(f"📄 Manifest gespeichert: {manifest_path}")

        return jsonify({
            "status": "ok",
            "binary_url": f"/firmware/{name}.bin",
            "manifest_url": f"/firmware/{name}.manifest.json"
        })

    except Exception as e:
        print("🔥 Fehler beim Kompilieren:")
        traceback.print_exc()
        return jsonify({"status": "error", "message": str(e)}), 500


@app.route("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


if __name__ == "__main__":
    print("🚀 ESPHome-Flasher Server läuft auf http://0.0.0.0:8099 ...")
    app.run(host="0.0.0.0", port=8099)
